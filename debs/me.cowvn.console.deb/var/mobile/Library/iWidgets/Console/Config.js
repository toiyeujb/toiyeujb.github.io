var Clock = "12h"; // "12h" or "24h"
var Lang = "vn";